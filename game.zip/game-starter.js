document.addEventListener("DOMContentLoaded", () => {
	// Engine.start(Platformer, "games/sample-platformer/sample-platformer.json");
	// Engine.start(GameTitle);
	Engine.start(WorldOfTurtle, null, true, true);
});
