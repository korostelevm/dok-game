const entrance = new Entrance(imageLoader);

document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(entrance);
});
