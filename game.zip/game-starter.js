document.addEventListener("DOMContentLoaded", () => {
	// Engine.start(Platformer, "games/sample-platformer/sample-platformer.json");
	// Engine.start(GameTitle);
	Engine.start(WorldOfTurtle, "games/turtle/world-of-turtle.json", true, true);
});
