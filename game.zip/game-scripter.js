const entrance = new Entrance();

document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(entrance);
});
