const globalFiles=[
	".DS_Store",
	{
		"assets": [
			".DS_Store",
			"annie.png",
			"background.png",
			"drug.gif",
			"dude-run.png",
			"dude-still.png",
			"elon.png",
			"eva-2.gif",
			"eva-turn.gif",
			"eva.gif",
			"hug.gif",
			"hug.png",
			"police.gif",
			"sexy.png"
		]
	},
	{
		"audio": [
			".DS_Store",
			"eva.mp3",
			"om.mp3"
		]
	},
	"favicon.ico",
	{
		"fonts": [
			".DS_Store"
		]
	},
	{
		"gen": [
			"data.js",
			"files.js"
		]
	},
	"index.html",
	{
		"lib": [
			".DS_Store",
			"engine.js",
			{
				"math": [
					"gl-matrix.js"
				]
			},
			{
				"newgrounds": [
					".DS_Store",
					"newgroundsio.min.js",
					"ng.js",
					"sound.mp3"
				]
			},
			{
				"opengl": [
					"buffer-renderer.js",
					"gl-wrapper.js",
					"shader.js",
					"utils.js"
				]
			},
			{
				"renderer": [
					"sprite-renderer.js"
				]
			},
			{
				"sprite": [
					"sprite-collection.js",
					"sprite.js"
				]
			},
			{
				"texture": [
					"image-loader.js",
					"texture-atlas.js",
					"texture-manager.js"
				]
			},
			{
				"ui": [
					"focus-fixer.js",
					"keyboard-handler.js"
				]
			}
		]
	},
	"package.json"
];