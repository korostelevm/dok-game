class Selection extends GameBase {
	constructor(imageLoader, data) {
		super(imageLoader, data);
	}

	async init(engine) {
		super.init(engine);
	}

	async postInit() {
	}

	clear(engine) {
	}

	handleMouse(e) {
	}

	onDropOnOverlay(e) {
	}

	refresh(time, dt) {
	}

}