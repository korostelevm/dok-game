const game = new Game();

document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(game);
});
