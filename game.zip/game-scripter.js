



document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(new Entrance());
});
