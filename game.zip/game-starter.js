document.addEventListener("DOMContentLoaded", () => {
	Engine.start(Platformer);
});
