const data = {
	gender: "T",	//	M,W,T
};

const entrance = new Entrance(imageLoader, data);

document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(entrance);
});
