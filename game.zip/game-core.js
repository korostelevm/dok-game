class GameCore {
	async init(engine) {
		const { gl, config } = engine;

	}

	refresh(time, dt) {
	}
}