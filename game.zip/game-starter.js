



document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(new Home());
});
