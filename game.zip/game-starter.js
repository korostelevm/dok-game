



document.addEventListener("DOMContentLoaded", () => {
	engine.setGame(new StartScreen());
});
